﻿using Jelena_Ndou_SOLID.model;
using System.Collections.Generic;

namespace Jelena_Ndou_SOLID
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee employee1 = new Employee("Marko", 10);
            Employee employee2 = new Employee("Ivana", 11);


            iTrain train1 = new BigTrain();
            iTrain train2 = new SmallTrain();

            iVehicle client1 = new Kombi();
            iVehicle client2 = new Bus();

            IList<WorkItem> terminal = new List<WorkItem>();

            WorkItem day2112023 = new WorkItem();

            // error na mali vlak veliko vozilo
            day2112023.Load(employee2, train2, client2);

            //SUCCESS
            day2112023.Load(employee1, train1, client1);




        }
    }
}
