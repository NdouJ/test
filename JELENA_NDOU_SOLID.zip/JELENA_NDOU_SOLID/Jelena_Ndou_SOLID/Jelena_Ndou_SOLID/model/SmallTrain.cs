﻿using System;

namespace Jelena_Ndou_SOLID.model
{
    public class SmallTrain : iTrain
    {
        private static int currentgas = 8;
        private static int currentStateSmallVehicles = 0;

        public int MaxCapacityBigVehicles => 0;

        public int MaxCapacitySmallVehicles => 8;

        public bool isbig => false;

        public void AddVehicleOnTrain(iVehicle vehicle)
        {
            if (vehicle.isBig)
            {
                Console.WriteLine("you cant put a big vehicle on a small train");
            }
            else
            {
                currentStateSmallVehicles++;
            }
        }

        public int CurrentStateSmallVehicles()
        {
            return currentStateSmallVehicles;
        }

        public int CurrenzStateBigVehicles()
        {
            return 0;
        }

        public void FillGasTank()
        {
            currentgas = 100;
        }

        public int GetCurrentGas()
        {
            return currentgas;
        }
    }
}
