﻿namespace Jelena_Ndou_SOLID.model
{
    public class Car : iVehicle
    {
        public int Price => 50;
        public bool isBig => false;
    }
}
