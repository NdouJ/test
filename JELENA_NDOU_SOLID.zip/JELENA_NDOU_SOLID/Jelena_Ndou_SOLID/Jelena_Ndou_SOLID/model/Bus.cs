﻿namespace Jelena_Ndou_SOLID.model
{
    public class Bus : iVehicle
    {
        public int Price => 70;

        public bool isBig => true;
    }
}
