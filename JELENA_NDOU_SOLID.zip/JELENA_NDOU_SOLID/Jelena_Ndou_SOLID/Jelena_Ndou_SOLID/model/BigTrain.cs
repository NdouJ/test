﻿namespace Jelena_Ndou_SOLID.model
{
    public class BigTrain : iTrain
    {


        private static int Gas = 0;

        public int MaxCapacityBigVehicles => 6;

        public int MaxCapacitySmallVehicles => 8;

        public bool isbig => true;

        private int currentStateBigVehicles;
        private int currentStateSmallVehicles;
        public int CurrentStateSmallVehicles()
        {
            return currentStateSmallVehicles;
        }

        public int CurrenzStateBigVehicles()
        {
            return currentStateBigVehicles;
        }

        public int GetCurrentGas()
        {
            return Gas;
        }

        public void FillGasTank()
        {
            Gas = 100;
        }

        public void AddVehicleOnTrain(iVehicle vehicle)
        {
            if (vehicle.isBig)
            {
                currentStateBigVehicles++;
            }
            else
            {
                currentStateSmallVehicles++;
            }
        }
    }
}
