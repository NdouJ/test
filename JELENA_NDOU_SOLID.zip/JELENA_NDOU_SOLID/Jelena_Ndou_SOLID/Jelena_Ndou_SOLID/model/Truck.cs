﻿namespace Jelena_Ndou_SOLID.model
{
    public class Truck : iVehicle
    {
        public int Price => 90;

        public bool isBig => true;
    }
}
