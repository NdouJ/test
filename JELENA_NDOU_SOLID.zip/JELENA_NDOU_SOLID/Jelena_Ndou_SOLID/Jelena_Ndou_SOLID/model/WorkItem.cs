﻿using System;

namespace Jelena_Ndou_SOLID.model
{
    public class WorkItem : iWork
    {
        public void Load(Employee employee, iTrain train, iVehicle vehicle)
        {
            if (vehicle.isBig)
            {

                if (train.isbig)
                {
                    if (train.CurrenzStateBigVehicles() < train.MaxCapacityBigVehicles)
                    {
                        Console.WriteLine("LOADING.... ");
                        train.AddVehicleOnTrain(vehicle);
                    }
                    else
                    {
                        Console.WriteLine("max capacity ");
                        return;
                    }
                }

                else
                {
                    Console.WriteLine("Error: You can't load a big vehicle on a small train! ");
                    return;
                }

            }

            else
            {
                if (train.CurrentStateSmallVehicles() < train.MaxCapacitySmallVehicles)
                {
                    Console.WriteLine("LOADING.... ");
                    train.AddVehicleOnTrain(vehicle);
                }
                else
                {
                    Console.WriteLine("max capacity ");
                    return;
                }

            }

            double money = employee.Earning / 100 * vehicle.Price;

            employee.SetTotalEarning(money);
            Console.WriteLine(employee.Name + "HAS EARNED NOW HIS TOTAL EARNING IS " + employee.GetTotalEarning());
        }

        public void AddGass(Employee employee, iTrain train)
        {
            if (train.GetCurrentGas() <= 10)
            {
                train.FillGasTank();
            }
            else
            {
                Console.WriteLine("There is more then 10% gass can't add");
            }
        }
    }
}
