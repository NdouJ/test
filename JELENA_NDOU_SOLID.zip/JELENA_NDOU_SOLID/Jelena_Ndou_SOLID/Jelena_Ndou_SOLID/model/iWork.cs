﻿using Jelena_Ndou_SOLID.model;

namespace Jelena_Ndou_SOLID
{
    public interface iWork
    {
        void Load(Employee employee, iTrain train, iVehicle vehicle);
        void AddGass(Employee employee, iTrain train);
    }
}
