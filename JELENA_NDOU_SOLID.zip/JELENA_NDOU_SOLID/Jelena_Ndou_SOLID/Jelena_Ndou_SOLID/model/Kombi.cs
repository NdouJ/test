﻿namespace Jelena_Ndou_SOLID.model
{
    public class Kombi : iVehicle
    {


        //public int MaxCapacity { get; } = 6;
        public bool isBig => false;

        public int Price => 80;


    }
}
