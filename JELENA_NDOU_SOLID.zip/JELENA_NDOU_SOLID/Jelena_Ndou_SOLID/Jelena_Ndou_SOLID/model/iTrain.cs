﻿namespace Jelena_Ndou_SOLID.model
{
    public interface iTrain
    {


        int MaxCapacityBigVehicles { get; }
        int MaxCapacitySmallVehicles { get; }

        bool isbig { get; }




        int GetCurrentGas();
        void FillGasTank();

        int CurrenzStateBigVehicles();
        int CurrentStateSmallVehicles();

        void AddVehicleOnTrain(iVehicle vehicle);


    }
}
