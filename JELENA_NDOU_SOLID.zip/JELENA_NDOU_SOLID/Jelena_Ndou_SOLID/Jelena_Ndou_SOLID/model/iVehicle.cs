﻿namespace Jelena_Ndou_SOLID.model
{
    public interface iVehicle

    {
        int Price { get; }
        bool isBig { get; }

    }


}
