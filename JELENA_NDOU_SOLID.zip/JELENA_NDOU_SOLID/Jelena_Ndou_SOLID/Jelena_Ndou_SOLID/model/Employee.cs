﻿namespace Jelena_Ndou_SOLID.model
{
    public class Employee
    {


        public string Name { get; set; }
        public double Earning { get; set; }

        private static double TotalEarning = 0;


        public Employee(string name, int earning)
        {
            Name = name;
            Earning = earning;
        }

        public override string ToString()
        {

            return $"{Name} {Earning}";

        }

        public double GetTotalEarning()
        {
            return TotalEarning;
        }

        public void SetTotalEarning(double earningNow)
        {

            TotalEarning += earningNow;
        }
    }




}
